                <!-- Sayfa içeriği burada bitecek -->
            </main>
        </div>
    </div>
    
    <footer class="text-right p-4 bg-gray-100 text-xs text-gray-500 border-t border-gray-200">
        <span>© <?php echo date('Y'); ?> Müsabaka Bilgi Sistemi. Tüm Hakları Saklıdır.</span>
        <a href="mailto:emre4koc@gmail.com" class="ml-4 font-semibold text-gray-700 hover:text-blue-600 hover:underline">İletişim</a>
    </footer>

    <script src="<?php echo BASE_URL; ?>/public/js/main.js?v=<?php echo time(); ?>"></script>
</body>
</html>